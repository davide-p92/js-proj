#include <stdio.h>

int main() {
	printf("Hello, Dav!\n");
	return 0;
}
